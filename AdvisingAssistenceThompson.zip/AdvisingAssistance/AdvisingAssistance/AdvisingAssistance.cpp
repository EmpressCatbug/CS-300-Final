#include <iostream>
#include <fstream>
#include <sstream>
#include <map>
#include <vector>
#include <queue>
#include <cctype>
#include <algorithm>

using namespace std;

class Course {
public:
    string courseNumber;
    string title;
    vector<string> prerequisites;

    // Default constructor
    Course() {}

    // Constructor to initialize the course with details
    Course(string num, string tit, vector<string> prereqs) :
        courseNumber(num), title(tit), prerequisites(prereqs) {}
};

// Function prototypes
void loadCourses(map<string, Course>& courses);
void printCourseList(const map<string, Course>& courses);
void printCourse(const map<string, Course>& courses);
void showMenu();
void createCourseFile(const string& filename);
string toUpper(const string& str);

int main() {
    map<string, Course> courses;
    bool dataLoaded = false;

    // Create the course data file if it does not exist
    createCourseFile("Courses.txt");

    // Display welcome message
    cout << "Welcome to the course planner.\n" << endl;

    while (true) {
        showMenu();
        int choice;
        cout << "What would you like to do? ";
        cin >> choice;
        cin.ignore(); // Ignore newline character left in the input buffer

        switch (choice) {
        case 1:
            loadCourses(courses);
            dataLoaded = true;
            break;
        case 2:
            if (dataLoaded) {
                printCourseList(courses);
            }
            else {
                cout << "Please load data structure first." << endl;
            }
            break;
        case 3:
            if (dataLoaded) {
                printCourse(courses);
            }
            else {
                cout << "Please load data structure first." << endl;
            }
            break;
        case 9:
            cout << "Thank you for using the course planner!" << endl;
            return 0;
        default:
            cout << choice << " is not a valid option. Please try again." << endl;
        }
    }
}

void createCourseFile(const string& filename) {
    ofstream file(filename);
    if (file.is_open()) {
        file << "MATH201,Discrete Mathematics\n";
        file << "CSCI300,Introduction to Algorithms,CSCI200,MATH201\n";
        file << "CSCI350,Operating Systems,CSCI300\n";
        file << "CSCI101,Introduction to Programming in C++,CSCI100\n";
        file << "CSCI100,Introduction to Computer Science\n";
        file << "CSCI301,Advanced Programming in C++,CSCI101\n";
        file << "CSCI400,Large Software Development,CSCI301,CSCI350\n";
        file << "CSCI200,Data Structures,CSCI101\n";
        file.close();
    }
    else {
        cout << "Unable to create file." << endl;
    }
}

string toUpper(const string& str) {
    string upperStr = str;
    transform(upperStr.begin(), upperStr.end(), upperStr.begin(),
        [](unsigned char c) { return toupper(c); });
    return upperStr;
}

void loadCourses(map<string, Course>& courses) {
    string filename;
    cout << "Enter the filename: ";
    getline(cin, filename);

    ifstream file(filename);
    if (!file) {
        cout << "Error opening file." << endl;
        return;
    }

    string line;
    while (getline(file, line)) {
        stringstream ss(line);
        string courseNumber, title, prereq;
        getline(ss, courseNumber, ',');
        courseNumber = toUpper(courseNumber);  // Convert course number to uppercase
        getline(ss, title, ',');

        vector<string> prerequisites;
        while (getline(ss, prereq, ',')) {
            prerequisites.push_back(toUpper(prereq));  // Convert prerequisites to uppercase
        }

        courses[courseNumber] = Course(courseNumber, title, prerequisites);
    }

    file.close();
    cout << "Data loaded successfully." << endl;
}

void printCourseList(const map<string, Course>& courses) {
    cout << "Here is a sample schedule:" << endl;
    for (const auto& pair : courses) {
        cout << pair.first << ", " << pair.second.title << endl;
    }
}

void printCourse(const map<string, Course>& courses) {
    string courseNumber;
    cout << "Enter the course number: ";
    getline(cin, courseNumber);
    courseNumber = toUpper(courseNumber);  // Convert input to uppercase before searching

    auto it = courses.find(courseNumber);
    if (it != courses.end()) {
        cout << it->second.courseNumber << ", " << it->second.title << endl;
        cout << "Prerequisites: ";
        for (const string& prereq : it->second.prerequisites) {
            cout << prereq << " ";
        }
        cout << endl;
    }
    else {
        cout << "Course not found." << endl;
    }
}

void showMenu() {
    cout << "\nMenu Options:" << endl;
    cout << "1. Load Data Structure." << endl;
    cout << "2. Print Course List." << endl;
    cout << "3. Print Course." << endl;
    cout << "9. Exit" << endl;
}
